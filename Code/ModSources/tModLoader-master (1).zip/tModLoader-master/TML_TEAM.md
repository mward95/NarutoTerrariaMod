The tModLoader Team (also tML Team) is the legal entity holding ownership of the tModLoader brand and software. 
Current members are: Kaylee Kim (blushiemagic), David Jakes (Chicken-Bones), Javid Pack (jopojelly), Daniël Zondervan (Jofairden) and Dmitry Reshetov (Mirsario)

Members can be added or removed only through unanimous vote. If a member is uncontactable for 2 weeks, they are considered to abstain from voting.

tModLoader is published under the MIT license, permitting distribution and modification of the software. By contributing to tML, contributors agree to the use of their contribution as part of tML under the MIT license.
The tML Team retains ownership of the tModLoader brand, and requests that derivative works be distinguished from the primary product. Major decisions impacting the tModLoader brand are also decided unanimously.
