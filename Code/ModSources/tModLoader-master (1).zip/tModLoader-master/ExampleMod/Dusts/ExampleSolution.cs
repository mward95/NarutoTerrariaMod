using Terraria.ModLoader;

namespace ExampleMod.Dusts
{
	public class ExampleSolution : ModDust
	{
		public override void SetDefaults() {
			updateType = 110;
		}
	}
}