### What are the changes to ExampleMod?

### Do these changes need additional documentation?
<!-- If you feel like these examples deserve more attention, such as in a tutorial, let us know here -->

