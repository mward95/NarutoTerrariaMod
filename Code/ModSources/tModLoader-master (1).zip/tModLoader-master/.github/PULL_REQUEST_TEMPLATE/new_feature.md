### What is the new feature?

### Why should this be part of tModLoader?

### Are there alternative designs?

### Sample usage for the new feature

### ExampleMod updates
<!-- If you also updated ExampleMod for your new feature, let us know here -->

