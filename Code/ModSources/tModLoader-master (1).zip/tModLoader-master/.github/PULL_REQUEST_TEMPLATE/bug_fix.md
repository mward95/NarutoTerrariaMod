### What is the bug?

### How did you fix the bug?

### Are there alternatives to your fix?

