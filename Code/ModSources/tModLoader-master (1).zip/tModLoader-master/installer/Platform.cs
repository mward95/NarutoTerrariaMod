using System;

namespace Installer
{
	public enum Platform
	{
		SETUP,
		WINDOWS,
		MAC,
		LINUX
	}
}
