namespace Terraria.ModLoader.UI.ModBrowser
{
	internal enum ModIconStatus
	{
		UNKNOWN,
		WANTED,
		REQUESTED,
		READY,
		APPENDED
	}
}