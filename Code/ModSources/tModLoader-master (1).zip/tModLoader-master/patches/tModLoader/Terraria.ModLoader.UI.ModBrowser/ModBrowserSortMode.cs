﻿namespace Terraria.ModLoader.UI.ModBrowser
{
	public enum ModBrowserSortMode
	{
		DisplayNameAtoZ,
		DisplayNameZtoA,
		DownloadsDescending,
		DownloadsAscending,
		RecentlyUpdated,
		Hot,
	}
}
