﻿namespace Terraria.ModLoader.UI.ModBrowser
{
	public enum ModSideFilter
	{
		All,
		Both,
		Client,
		Server,
		NoSync
	}
}
