﻿namespace Terraria.ModLoader.UI.ModBrowser
{
	public enum SearchFilter
	{
		Name,
		Author
	}
}
