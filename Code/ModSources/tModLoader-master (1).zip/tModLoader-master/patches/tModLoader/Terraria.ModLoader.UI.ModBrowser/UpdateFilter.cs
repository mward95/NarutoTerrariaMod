﻿namespace Terraria.ModLoader.UI.ModBrowser
{
	public enum UpdateFilter
	{
		All,
		Available,
		UpdateOnly,
		InstalledOnly
	}
}
