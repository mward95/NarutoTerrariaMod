using System;

namespace Terraria.ID
{
	public static class LangID
	{
		public const int English = 1;
		public const int German = 2;
		public const int Italian = 3;
		public const int French = 4;
		public const int Spanish = 5;
	}
}
