using System;

namespace Terraria.ID
{
	public static class NetmodeID
	{
		public const int SinglePlayer = 0;
		public const int MultiplayerClient = 1;
		public const int Server = 2;
	}
}
