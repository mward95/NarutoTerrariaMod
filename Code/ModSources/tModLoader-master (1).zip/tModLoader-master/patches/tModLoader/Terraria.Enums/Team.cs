﻿namespace Terraria.Enums
{
	public enum Team : byte
	{
		None,
		Red,
		Green,
		Blue,
		Yellow,
		Pink
	}
}